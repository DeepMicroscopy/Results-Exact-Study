from fastai import *
from fastai.vision import *
from fastai.callbacks import *
from fastai.layers import LabelSmoothingCrossEntropy

class LabelSmoothingProbCrossEntropy(Module):
    def __init__(self, eps:float=0.1, reduction='mean'): 
        self.eps,self.reduction = eps,reduction

    def forward(self, output, target):
        c = output.size()[-1]
        log_preds = F.log_softmax(output, dim=-1)
        if self.reduction=='sum': 
            loss = -log_preds.sum()
        else:
            loss = -log_preds.sum(dim=-1)
            if self.reduction=='mean':  
                loss = loss.mean()
        return loss*self.eps/c + (1-self.eps) * F.nll_loss(log_preds, target, reduction=self.reduction)

folder = Path('D:/ProgProjekte/Python/Results-Exact-Study/Patches')
path = folder/"ExpertAlgorithm"

tfms = get_transforms(do_flip=True, 
                      flip_vert=True, 
                      max_rotate=90,  
                      #max_lighting=0.0, 
                      #max_zoom=2, 
                      #max_warp=0.2,
                      #p_affine=0.75,
                      #p_lighting=0.75,  
                      #xtra_tfms=xtra_tfms,
                     )

#def get_data(bs,size):
#    data = ImageDataBunch.from_folder(path, train="train", valid="val", size=size, bs=bs, ds_tfms=tfms, num_workers=0)
#    return data.normalize()

def get_float_labels(x: Path):

    votes = 10
    if '_' in x.stem:
        votes = int(x.stem.split('_')[0])
    return (x.parent.stem, votes)


def get_data(bs,size):
    return (ImageList.from_folder(path)
        .split_by_folder(train="train", valid="val")
        .label_from_func(get_float_labels, label_cls=FloatList)
        .transform(tfms, size=size)
        .databunch(bs=bs)).normalize()


data = get_data(64,64)

crit = LabelSmoothingProbCrossEntropy()
learn = cnn_learner(get_data(bs=64, size=64), models.resnet18, metrics=[error_rate, accuracy], callback_fns=[ShowGraph], loss_func=crit)

lr = 0.05
learn.fit_one_cycle(5, slice(lr))